/*
 * buzzer.h
 *
 *  Created on: 14.09.2011
 *      Author: daniel
 */

#ifndef BUZZER_H_
#define BUZZER_H_

void buzzer_handler(unsigned int);
void buzzer(unsigned char);

#endif /* BUZZER_H_ */
